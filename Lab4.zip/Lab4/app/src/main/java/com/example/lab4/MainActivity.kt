package com.example.lab4

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val loginField = findViewById<EditText>(R.id.editTextLogin)
        val passwordField = findViewById<EditText>(R.id.editTextPassword)
        val buttonLogin = findViewById<Button>(R.id.buttonLogin)
        val messageText = findViewById<TextView>(R.id.textMessage)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        buttonLogin.setOnClickListener {
            val login = loginField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            // Перевірка на порожні поля
            if (login.isEmpty() || password.isEmpty()) {
                messageText.text = "Будь ласка, заповніть усі поля"
                return@setOnClickListener
            }

            // Валідація паролю (мінімум 6 символів)
            if (password.length < 6) {
                messageText.text = "Пароль має містити щонайменше 6 символів"
                return@setOnClickListener
            }

            // Якщо все окей
            messageText.setTextColor(getColor(android.R.color.holo_green_dark))
            messageText.text = "Вхід успішний"
            Toast.makeText(this, "Ласкаво просимо, $login!", Toast.LENGTH_SHORT).show()
        }
    }
}