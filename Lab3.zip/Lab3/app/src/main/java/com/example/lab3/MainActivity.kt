package com.example.lab3

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Context
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch


class MainActivity : AppCompatActivity() {

    private lateinit var switch1: Switch
    private lateinit var switch2: Switch
    private lateinit var check1: CheckBox
    private lateinit var check2: CheckBox
    private lateinit var radioGroup: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        switch1 = findViewById(R.id.switchOption1)
        switch2 = findViewById(R.id.switchOption2)
        check1 = findViewById(R.id.checkOption1)
        check2 = findViewById(R.id.checkOption2)
        radioGroup = findViewById(R.id.radioGroup)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun onPause() {
        super.onPause()
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putBoolean("switch1", switch1.isChecked)
        editor.putBoolean("switch2", switch2.isChecked)
        editor.putBoolean("check1", check1.isChecked)
        editor.putBoolean("check2", check2.isChecked)
        editor.putInt("radio", radioGroup.checkedRadioButtonId)
        editor.apply()
    }

    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        switch1.isChecked = prefs.getBoolean("switch1", true)
        switch2.isChecked = prefs.getBoolean("switch2", false)
        check1.isChecked = prefs.getBoolean("check1", true)
        check2.isChecked = prefs.getBoolean("check2", false)
        val radioId = prefs.getInt("radio", R.id.radioOption1)
        findViewById<RadioButton>(radioId).isChecked = true
    }
}