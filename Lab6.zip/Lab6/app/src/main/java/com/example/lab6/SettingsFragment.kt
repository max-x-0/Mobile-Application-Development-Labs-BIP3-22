package com.example.lab6

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Switch
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import java.util.*

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val switchTheme = view.findViewById<Switch>(R.id.switchTheme)
        val btnUa = view.findViewById<Button>(R.id.btnUa)
        val btnEn = view.findViewById<Button>(R.id.btnEn)

        val prefs = requireContext().getSharedPreferences(Prefs.PREFS, Context.MODE_PRIVATE)
        val savedTheme = prefs.getString(Prefs.KEY_THEME, "light")
        switchTheme.isChecked = savedTheme == "dark"

        switchTheme.setOnCheckedChangeListener { _, isChecked ->
            Prefs.saveTheme(requireContext(), isChecked)
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
        }

        fun changeLang(lang: String) {
            val code = if (lang == "ua") "uk" else "en"
            prefs.edit().putString(Prefs.KEY_LANG, lang).apply()
            val locale = Locale(code)
            Locale.setDefault(locale)
            val res = requireContext().resources
            val conf = res.configuration
            conf.setLocale(locale)
            res.updateConfiguration(conf, res.displayMetrics)
            requireActivity().recreate()
        }

        btnUa.setOnClickListener { changeLang("ua") }
        btnEn.setOnClickListener { changeLang("en") }
    }
}
