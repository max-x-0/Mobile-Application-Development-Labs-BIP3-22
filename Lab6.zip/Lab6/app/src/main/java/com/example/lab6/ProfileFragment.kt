package com.example.lab6

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment(R.layout.fragment_profile) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val tvName = view.findViewById<TextView>(R.id.tvName)
        val tvEmail = view.findViewById<TextView>(R.id.tvEmail)
        val tvCart = view.findViewById<TextView>(R.id.tvCartCount)
        val btnClear = view.findViewById<Button>(R.id.btnClearCart)

        val prefs = requireContext().getSharedPreferences(Prefs.PREFS, 0)
        val name = prefs.getString(Prefs.KEY_NAME, "—")
        val email = prefs.getString(Prefs.KEY_EMAIL, "—")

        tvName.text = getString(R.string.profile_name, name)
        tvEmail.text = getString(R.string.profile_email, email)

        fun updateCartInfo() {
            val cart = Prefs.getCartList(requireContext())
            tvCart.text = getString(R.string.cart_items, cart.size)
        }

        updateCartInfo()

        btnClear.setOnClickListener {
            Prefs.clearCart(requireContext())
            updateCartInfo()
        }
    }
}
