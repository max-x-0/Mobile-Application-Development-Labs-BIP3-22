package com.example.lab6

import android.content.Context
import org.json.JSONArray
import java.util.*

object Prefs {
    const val PREFS = "app_prefs"
    const val KEY_NAME = "name"
    const val KEY_EMAIL = "email"
    const val KEY_ROLE = "role"
    const val KEY_THEME = "theme"
    const val KEY_LANG = "lang"
    const val KEY_CART = "cart"

    fun addToCart(ctx: Context, title: String) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(KEY_CART, "[]") ?: "[]"
        val arr = JSONArray(current)
        arr.put(title)
        prefs.edit().putString(KEY_CART, arr.toString()).apply()
    }

    fun getCartList(ctx: Context): MutableList<String> {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(KEY_CART, "[]") ?: "[]"
        val arr = JSONArray(current)
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) list.add(arr.optString(i))
        return list
    }

    fun clearCart(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_CART, "[]").apply()
    }

    fun saveUser(ctx: Context, name: String, email: String, role: String = "user") {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_NAME, name)
            .putString(KEY_EMAIL, email)
            .putString(KEY_ROLE, role)
            .apply()
    }

    fun applyThemeFromPrefs() {

    }

    fun saveTheme(ctx: Context, dark: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_THEME, if (dark) "dark" else "light").apply()
    }

    fun saveLang(ctx: Context, lang: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LANG, lang).apply()
    }
}
