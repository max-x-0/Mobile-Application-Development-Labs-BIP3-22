package com.example.lab6

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeFragment : Fragment(R.layout.fragment_home) {

    private val products by lazy {
        listOf(
            Product(getString(R.string.product_phone), "15000 ${getString(R.string.currency)}"),
            Product(getString(R.string.product_headphones), "2000 ${getString(R.string.currency)}"),
            Product(getString(R.string.product_monitor), "7000 ${getString(R.string.currency)}"),
            Product(getString(R.string.product_keyboard), "1200 ${getString(R.string.currency)}"),
            Product(getString(R.string.product_laptop), "25000 ${getString(R.string.currency)}")
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val recycler = view.findViewById<RecyclerView>(R.id.recyclerViewProducts)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = ProductAdapter(products) { product ->
            Prefs.addToCart(requireContext(), product.title)
            Toast.makeText(requireContext(),
                getString(R.string.toast_added, product.title),
                Toast.LENGTH_SHORT).show()        }
    }
}
