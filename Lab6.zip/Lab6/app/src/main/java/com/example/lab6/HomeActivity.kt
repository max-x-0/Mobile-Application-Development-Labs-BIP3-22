package com.example.lab6

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.*

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedLocaleAndTheme()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val prefs = getSharedPreferences(Prefs.PREFS, Context.MODE_PRIVATE)
        intent.getStringExtra("USER_NAME")?.let { prefs.edit().putString(Prefs.KEY_NAME, it).apply() }
        intent.getStringExtra("USER_EMAIL")?.let { prefs.edit().putString(Prefs.KEY_EMAIL, it).apply() }
        prefs.edit().putString(Prefs.KEY_ROLE, "user").apply()

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, HomeFragment())
            .commit()

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            val frag: Fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_profile -> ProfileFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> HomeFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, frag)
                .commit()
            true
        }
    }

    private fun applySavedLocaleAndTheme() {
        val prefs = getSharedPreferences(Prefs.PREFS, Context.MODE_PRIVATE)
        val theme = prefs.getString(Prefs.KEY_THEME, "light")
        AppCompatDelegate.setDefaultNightMode(
            if (theme == "dark") AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        val lang = prefs.getString(Prefs.KEY_LANG, "ua") ?: "ua"
        val code = if (lang == "ua") "uk" else "en"
        val locale = Locale(code)
        Locale.setDefault(locale)
        val res = resources
        val conf = res.configuration
        conf.setLocale(locale)
        res.updateConfiguration(conf, res.displayMetrics)
    }
}
