package com.example.lab6

data class Product(val title: String, val price: String)
