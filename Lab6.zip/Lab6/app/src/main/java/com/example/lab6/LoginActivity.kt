package com.example.lab6

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.content.Context

class LoginActivity : AppCompatActivity() {

    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailInput = findViewById(R.id.loginEmail)
        passwordInput = findViewById(R.id.loginPassword)
        loginBtn = findViewById(R.id.buttonLogin)

        val regName = intent.getStringExtra("USER_NAME")
        val regEmail = intent.getStringExtra("USER_EMAIL")
        val regPass = intent.getStringExtra("USER_PASSWORD")

        loginBtn.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val pass = passwordInput.text.toString()

            if (email == regEmail && pass == regPass) {
                val prefs = getSharedPreferences(Prefs.PREFS, Context.MODE_PRIVATE)
                prefs.edit().putString(Prefs.KEY_NAME, regName)
                    .putString(Prefs.KEY_EMAIL, regEmail)
                    .putString(Prefs.KEY_ROLE, "user")
                    .apply()

                val intent = Intent(this, HomeActivity::class.java)
                intent.putExtra("USER_NAME", regName)
                intent.putExtra("USER_EMAIL", regEmail)
                startActivity(intent)
            } else {
                Toast.makeText(this, getString(R.string.error_invalid_data), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
