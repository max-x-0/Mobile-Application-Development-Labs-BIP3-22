package com.example.lab7

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class GameView(context: Context) : View(context) {

    private val paint = Paint().apply {
        color = Color.BLUE
        isAntiAlias = true
    }

    private var xPos = 300f
    private var yPos = 300f
    private val radius = 60f

    private var xSpeed = 0f
    private var ySpeed = 0f

    fun updatePosition(dx: Float, dy: Float) {
        xSpeed += dx
        ySpeed += dy

        xPos += xSpeed * 0.1f
        yPos += ySpeed * 0.1f

        if (xPos - radius < 0) xPos = radius
        if (xPos + radius > width) xPos = width - radius
        if (yPos - radius < 0) yPos = radius
        if (yPos + radius > height) yPos = height - radius

        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.WHITE)
        canvas.drawCircle(xPos, yPos, radius, paint)
    }
}
